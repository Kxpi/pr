#include <cstdio>
#include <cstdint>
#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

int is_prime(int number) {
    int sqrt_max = sqrt(number);
    for (int i = 2; i <= sqrt_max; i++) {
        if (number % i == 0)
            return 0;
    }
    return 1;
}

int prime_numbers_division(int min, int max, char* numbers, int threads) {
    int i=0;
    int res = 0;
    int total = 0;
    int range = max - min + 1;
    numbers[range] = { 0 };
    omp_set_num_threads(threads);
#pragma omp parallel shared(i) private(res)
    {
#pragma omp for schedule(dynamic, 200) reduction(+:total)
        for (int i = 0; i < range; ++i) {
            res = is_prime(min + i);
            numbers[i] = res;
            total += res;
        }
    }

    return total;
}



int main(int argc, char* argv[]) {
    int min = atoi(argv[1]);
    int max = atoi(argv[2]);
    int threads = atoi(argv[3]);
    bool print = false;
    
    if (argc>4) {
        print = true;
    }
    if (min < 2) {
        min = 2;
    }
    int size = max - min + 1;
    char* numbers = (char*)malloc(((size)) * sizeof(char));
    
    omp_set_num_threads(threads);
    
    double t0 = omp_get_wtime();
    int num_of_primes = prime_numbers_division(min, max, numbers, threads);
    double t1 = omp_get_wtime();
    double res = t1 - t0;
    
    printf("Found: %d primes in %.6f seconds\n", num_of_primes, res);
    
    if (print) {
        int counter = 0;
        for (int i = 0; i < size; ++i) {
            if (numbers[i]) {
                printf("%d, ", i + min);
                counter++;
            }
            if (counter == 10) {
                printf("\n");
                counter = 0;
            }
        }
    }
    free(numbers);
}