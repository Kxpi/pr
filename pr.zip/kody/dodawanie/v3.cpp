#include <cstdio>
#include <cstdint>
#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <assert.h>

#define MIN(a, b) (((a) < (b)) ? (a):(b))
#define MAX(a, b) (((a) > (b)) ? (a):(b))


int eratosthenes(int min, int max, char* numbers, char* prime_nums, int prime_nums_size, int threads) {
    int size = max - min + 1;
    int thread, i;
    int total = 0, iterationsPerThread = (max - min) / threads;
    int padValue = 0;
    // Assign additional iterations to thread with ID 0 if number of iterations is not divisible by threads
    if (iterationsPerThread * threads != size)
        padValue = (max - min) - (iterationsPerThread * threads);

#pragma omp parallel shared(i, thread)
    {
        // Initialize prime_nums array
#pragma omp for nowait
        for (i = 0; i < prime_nums_size; ++i)
            prime_nums[i] = 1;

        // Initialize numbers array
#pragma omp for
        for (i = 0; i < size; ++i)
            numbers[i] = 1;

        // Find prime numbers in range <2; sqrt(max)>
#pragma omp for
        for (i = 2; i < prime_nums_size; ++i) {
            if (prime_nums[i]) {
                for (int j = i * i; j < prime_nums_size; j += i) {
                    if (prime_nums[j] > 0)
                        prime_nums[j] = 0;
                }
            }
        }

#pragma omp for
        for (thread = 0; thread < threads; ++thread) {
            int start = MAX(min + thread * iterationsPerThread + (thread != 0 ? padValue : 0), 2); // First value to possibly mark as non-prime number(included)
            int end = start + iterationsPerThread + (thread == 0 ? padValue : 0) + (thread == threads - 1 ? 1 : 0); // Last value to possibly mark as non-prime number(included only in last thread)

            for (int i = 2; i < prime_nums_size; ++i) {
                if (prime_nums[i] > 0) {
                    int first = start % i == 0 ? start : start + (i - start % i);
                    if (first < prime_nums_size && prime_nums[first] != 0)
                        first += i;

                    int until = end - min;
                    for (int j = first - min; j < until; j += i) {
                        if (numbers[j] > 0)
                            numbers[j] = 0;
                    }
                }
            }
        }
#pragma omp for reduction(+: total)  
        for (i = 0; i < size; ++i) {
            if (numbers[i] > 0)
                total += 1;
        }

    }
    return total;
}


int main(int argc, char* argv[]) {
    int min = atoi(argv[1]);
    int max = atoi(argv[2]);
    int threads = atoi(argv[3]);
    bool print = false;

    if (argc > 4) {
        print = true;
    }
    if (min < 2) {
        min = 2;
    }
    int size = max - min + 1;
    char* numbers = (char*)malloc(((size)) * sizeof(char));
    int prime_nums_size = sqrt(max) + 1;
    char* prime_nums = (char*)malloc(prime_nums_size * sizeof(char));

    double t0 = omp_get_wtime();
    double res = 0;
    int num_of_primes;
    
    while (res < 5.0) {
        num_of_primes = eratosthenes(min, max, numbers, prime_nums, prime_nums_size, threads);
        double t1 = omp_get_wtime();
        res = t1 - t0;
    }

    printf("Found: %d primes in %.6f seconds\n", num_of_primes, res);

    if (print) {
        int counter = 0;
        for (int i = 0; i < size; ++i) {
            if (numbers[i]) {
                printf("%d, ", i + min);
                counter++;
            }
            if (counter == 10) {
                printf("\n");
                counter = 0;
            }
        }
    }

    free(prime_nums);
    free(numbers);
}