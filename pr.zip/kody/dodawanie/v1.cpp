#include <cstdio>
#include <cstdint>
#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>


int eratosthenes(int min, int max, char* numbers) {
    int total = 0;
    int size = max - min + 1;
    int prime_nums_size = sqrt(max) + 1;
    char* prime_nums = (char*)malloc(prime_nums_size * sizeof(char));

    for (int i = 0; i < prime_nums_size; ++i)
        prime_nums[i] = 1;

    for (int i = 0; i < size; ++i)
        numbers[i] = 1;

    for (int i = 2; i < prime_nums_size; ++i) {
        if (prime_nums[i]) {
            for (int j = i * i; j < prime_nums_size; j += i)
                prime_nums[j] = 0;
        }
    }

    for (int i = 2; i < prime_nums_size; ++i) {
        if (prime_nums[i] > 0) {
            for (int j = i * i; j <= max; j += i) {
                if (numbers[j - min] > 0 && j >= min)
                    numbers[j - min] = 0;
            }
        }
    }

    free(prime_nums);

    for (int i = 0; i < size; ++i) {
        total += numbers[i];
    }

    return total;

}


int main(int argc, char* argv[]) {
    int min = atoi(argv[1]);
    int max = atoi(argv[2]);
    int threads = atoi(argv[3]);
    bool print = false;

    if (argc > 4) {
        print = true;
    }
    if (min < 2) {
        min = 2;
    }
    int size = max - min + 1;
    char* numbers = (char*)malloc(((size)) * sizeof(char));

    double t0 = omp_get_wtime();
    int num_of_primes = eratosthenes(min, max, numbers);
    double t1 = omp_get_wtime();
    double res = t1 - t0;

    printf("Found: %d primes in %.6f seconds\n", num_of_primes, res);

    if (print) {
        int counter = 0;
        for (int i = 0; i < size; ++i) {
            if (numbers[i]) {
                printf("%d, ", i + min);
                counter++;
            }
            if (counter == 10) {
                printf("\n");
                counter = 0;
            }
        }
    }
    free(numbers);
}